using System;
using System.Collections.Generic;
using Wisej.Web;

namespace Plot3D
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        static void Main()
        {
            new Graph3DMainForm().Show();
        }
    }
}